import os, re, secrets, time
from datetime import datetime, timedelta, date
from functools import wraps
from flask import Flask, render_template, request, jsonify, session, redirect, url_for, send_file
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from flask_socketio import SocketIO, join_room, emit
from sqlalchemy import func

BASE = os.path.abspath(os.path.dirname(__file__))
app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ.get("SECRET_KEY", "dev-only-change-this-secret"),
    SQLALCHEMY_DATABASE_URI="sqlite:///" + os.path.join(BASE, "streamer_buddy.db"),
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
    MAX_CONTENT_LENGTH=5 * 1024 * 1024,
    UPLOAD_FOLDER=os.path.join(BASE, "uploads"),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
)
db = SQLAlchemy(app)
socketio = SocketIO(app, cors_allowed_origins=[], async_mode="threading")
COIN_RATE = 0.10
PLATFORM_FEE = 10
PACKS = {100: 10, 500: 45, 1000: 85, 5000: 400}
GIFTS = {"Rose": 10, "Coffee": 50, "Trophy": 500, "Rocket": 1000}
BAD_WORDS = {"slur1", "slur2"}  # Replace with a maintained moderation provider/list.
send_windows = {}

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(40), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(12), nullable=False, default="fan")
    bio = db.Column(db.String(300), default="")
    avatar = db.Column(db.String(255), default="")
    cover = db.Column(db.String(255), default="")
    category = db.Column(db.String(40), default="gaming")
    live = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    def set_password(self, password): self.password_hash = generate_password_hash(password)
    def check_password(self, password): return check_password_hash(self.password_hash, password)

class Ledger(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), index=True, nullable=False)
    amount = db.Column(db.Integer, nullable=False)  # signed coin amount
    kind = db.Column(db.String(30), nullable=False)
    note = db.Column(db.String(240), default="")
    ref = db.Column(db.String(64), default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

class Follow(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    fan_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    creator_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    __table_args__ = (db.UniqueConstraint("fan_id", "creator_id"),)

class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    creator_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    text = db.Column(db.String(2000), nullable=False, default="")
    image = db.Column(db.String(255), default="")
    pinned = db.Column(db.Boolean, default=False)
    members_only = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Like(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    post_id = db.Column(db.Integer, db.ForeignKey("post.id"), nullable=False)
    __table_args__ = (db.UniqueConstraint("user_id", "post_id"),)

class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    post_id = db.Column(db.Integer, db.ForeignKey("post.id"), nullable=False)
    text = db.Column(db.String(500), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    text = db.Column(db.String(240), nullable=False)
    kind = db.Column(db.String(30), default="info")
    read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Payout(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    creator_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    coins = db.Column(db.Integer, nullable=False)
    amount_rupees = db.Column(db.Float, nullable=False)
    destination = db.Column(db.String(120), nullable=False)
    kind = db.Column(db.String(20), default="upi")
    status = db.Column(db.String(20), default="pending")
    redemption_code = db.Column(db.String(40), default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Report(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    reporter_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    target_type = db.Column(db.String(20), nullable=False)
    target_id = db.Column(db.Integer, nullable=False)
    reason = db.Column(db.String(500), nullable=False)
    status = db.Column(db.String(20), default="open")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Setting(db.Model):
    key = db.Column(db.String(50), primary_key=True)
    value = db.Column(db.String(100), nullable=False)

def current_user():
    uid = session.get("uid")
    return db.session.get(User, uid) if uid else None

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user(): return jsonify(error="Please log in to continue."), 401
        return fn(*args, **kwargs)
    return wrapper

def roles(*allowed):
    def deco(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            u = current_user()
            if not u: return jsonify(error="Please log in to continue."), 401
            if u.role not in allowed: return jsonify(error="You don't have permission to do that."), 403
            return fn(*args, **kwargs)
        return wrapper
    return deco

def balance(user_id):
    return db.session.query(func.coalesce(func.sum(Ledger.amount), 0)).filter_by(user_id=user_id).scalar() or 0

def add_ledger(user_id, amount, kind, note="", ref=""):
    db.session.add(Ledger(user_id=user_id, amount=amount, kind=kind, note=note, ref=ref))

def notify(user_id, text, kind="info"):
    db.session.add(Notification(user_id=user_id, text=text, kind=kind))
    socketio.emit("notification", {"text": text, "kind": kind}, room=f"user_{user_id}")

def settings():
    rows = {x.key: x.value for x in Setting.query.all()}
    return float(rows.get("coin_rate", COIN_RATE)), float(rows.get("platform_fee", PLATFORM_FEE))

def safe_text(value, max_len=500):
    value = str(value or "").strip()
    if len(value) > max_len: raise ValueError(f"Please keep this under {max_len} characters.")
    if any(word in value.lower().split() for word in BAD_WORDS):
        raise ValueError("Please remove abusive language and try again.")
    return value

def user_json(u):
    return {"id": u.id, "username": u.username, "email": u.email, "role": u.role,
            "bio": u.bio, "avatar": u.avatar, "cover": u.cover, "category": u.category,
            "live": u.live, "balance": balance(u.id),
            "followers": Follow.query.filter_by(creator_id=u.id).count()}

@app.after_request
def security_headers(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "SAMEORIGIN"
    resp.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    return resp

@app.get("/")
def index(): return render_template("index.html")

@app.get("/overlay")
def overlay_page(): return render_template("index.html")

@app.get("/api/me")
def me():
    u = current_user()
    if not u: return jsonify(user=None)
    return jsonify(user=user_json(u))

@app.post("/api/signup")
def signup():
    data = request.get_json(silent=True) or {}
    username, email, password = (str(data.get(k, "")).strip() for k in ("username", "email", "password"))
    role = data.get("role", "fan")
    if not re.fullmatch(r"[A-Za-z0-9_]{3,24}", username): return jsonify(error="Username must be 3–24 letters, numbers or underscores."), 400
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email): return jsonify(error="Enter a valid email address."), 400
    if len(password) < 8: return jsonify(error="Use at least 8 characters for your password."), 400
    if role not in ("fan", "creator"): return jsonify(error="Choose fan or creator."), 400
    if User.query.filter(db.or_(User.username.ilike(username), User.email.ilike(email))).first():
        return jsonify(error="That username or email is already registered."), 409
    u = User(username=username, email=email.lower(), role=role)
    u.set_password(password)
    db.session.add(u); db.session.flush()
    add_ledger(u.id, 100, "bonus", "Welcome bonus")
    db.session.commit()
    session["uid"] = u.id
    return jsonify(user=user_json(u)), 201

@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}
    email = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", ""))
    u = User.query.filter_by(email=email).first()
    if not u or not u.check_password(password): return jsonify(error="Email or password is incorrect."), 401
    session.clear(); session["uid"] = u.id
    return jsonify(user=user_json(u))

@app.post("/api/demo-login")
def demo_login():
    data = request.get_json(silent=True) or {}
    role = data.get("role")
    email = {"fan":"sam@sb.com", "creator":"nova@sb.com", "admin":"admin@sb.com"}.get(role)
    u = User.query.filter_by(email=email).first()
    if not u: return jsonify(error="Demo account isn't seeded yet. Restart the app."), 500
    session.clear(); session["uid"] = u.id
    return jsonify(user=user_json(u))

@app.post("/api/logout")
@login_required
def logout():
    session.clear()
    return jsonify(ok=True)

@app.get("/api/creators")
def creators():
    q = request.args.get("q", "").strip()
    category = request.args.get("category", "").strip()
    query = User.query.filter_by(role="creator")
    if q: query = query.filter(User.username.ilike(f"%{q[:40]}%"))
    if category and category != "all": query = query.filter_by(category=category)
    out = []
    for u in query.order_by(User.live.desc(), User.username).all():
        item = user_json(u); item["posts"] = Post.query.filter_by(creator_id=u.id).count()
        out.append(item)
    return jsonify(creators=out)

@app.get("/api/creators/<int:creator_id>")
def creator_detail(creator_id):
    u = db.session.get(User, creator_id)
    if not u or u.role != "creator": return jsonify(error="Creator not found."), 404
    posts = Post.query.filter_by(creator_id=u.id).order_by(Post.pinned.desc(), Post.created_at.desc()).all()
    me_u = current_user()
    result = []
    for p in posts:
        if p.members_only and (not me_u or not Follow.query.filter_by(fan_id=me_u.id, creator_id=u.id).first()):
            continue
        result.append({"id":p.id,"text":p.text,"image":p.image,"pinned":p.pinned,"created_at":p.created_at.isoformat(),
                       "likes":Like.query.filter_by(post_id=p.id).count(),
                       "liked":bool(me_u and Like.query.filter_by(user_id=me_u.id,post_id=p.id).first()),
                       "comments":[{"id":c.id,"text":c.text,"username":db.session.get(User,c.user_id).username} for c in Comment.query.filter_by(post_id=p.id).order_by(Comment.created_at.desc()).limit(20).all()]})
    return jsonify(creator=user_json(u), posts=result, following=bool(me_u and Follow.query.filter_by(fan_id=me_u.id,creator_id=u.id).first()))

@app.post("/api/follow/<int:creator_id>")
@roles("fan")
def follow(creator_id):
    u = db.session.get(User, creator_id)
    if not u or u.role != "creator": return jsonify(error="Creator not found."), 404
    if u.id == current_user().id: return jsonify(error="You can't follow yourself."), 400
    row = Follow.query.filter_by(fan_id=current_user().id, creator_id=u.id).first()
    if row:
        db.session.delete(row); following = False
    else:
        db.session.add(Follow(fan_id=current_user().id, creator_id=u.id)); notify(u.id, f"{current_user().username} followed you", "follow"); following = True
    db.session.commit()
    return jsonify(following=following, followers=Follow.query.filter_by(creator_id=u.id).count())

@app.post("/api/posts")
@roles("creator")
def create_post():
    data = request.get_json(silent=True) or {}
    try: body = safe_text(data.get("text"), 2000)
    except ValueError as e: return jsonify(error=str(e)), 400
    if not body and not data.get("image"): return jsonify(error="Add some text or a photo to your post."), 400
    if data.get("image") and not str(data["image"]).startswith("/uploads/"): return jsonify(error="Invalid image path."), 400
    p = Post(creator_id=current_user().id, text=body, image=data.get("image",""))
    db.session.add(p); db.session.commit()
    return jsonify(id=p.id), 201

@app.post("/api/posts/<int:post_id>/like")
@roles("fan")
def like_post(post_id):
    p = db.session.get(Post, post_id)
    if not p: return jsonify(error="Post not found."), 404
    row = Like.query.filter_by(user_id=current_user().id,post_id=p.id).first()
    if row: db.session.delete(row); liked=False
    else: db.session.add(Like(user_id=current_user().id,post_id=p.id)); liked=True
    db.session.commit()
    return jsonify(liked=liked, likes=Like.query.filter_by(post_id=p.id).count())

@app.post("/api/posts/<int:post_id>/comments")
@roles("fan")
def comment(post_id):
    p = db.session.get(Post, post_id)
    if not p: return jsonify(error="Post not found."), 404
    try: body = safe_text((request.get_json(silent=True) or {}).get("text"), 500)
    except ValueError as e: return jsonify(error=str(e)), 400
    if not body: return jsonify(error="Write a comment first."), 400
    c=Comment(user_id=current_user().id,post_id=p.id,text=body)
    db.session.add(c); notify(p.creator_id, f"{current_user().username} commented on your post", "comment"); db.session.commit()
    return jsonify(id=c.id, username=current_user().username, text=c.text), 201

@app.delete("/api/comments/<int:comment_id>")
@roles("creator")
def delete_comment(comment_id):
    c=db.session.get(Comment,comment_id)
    if not c: return jsonify(error="Comment not found."),404
    p=db.session.get(Post,c.post_id)
    if p.creator_id != current_user().id: return jsonify(error="You can only delete comments on your posts."),403
    db.session.delete(c); db.session.commit(); return jsonify(ok=True)

@app.post("/api/wallet/buy")
@roles("fan")
def buy_coins():
    data=request.get_json(silent=True) or {}
    try: pack=int(data.get("pack",0))
    except (TypeError,ValueError): pack=0
    method=data.get("method")
    if pack not in PACKS: return jsonify(error="Choose one of the available coin packs."),400
    if method not in ("upi","card","netbanking"): return jsonify(error="Choose a payment method."),400
    # Simulated payment only: no card data is accepted or persisted.
    if method=="upi" and not re.fullmatch(r"[A-Za-z0-9._-]{2,}@[A-Za-z]{2,}",str(data.get("upi",""))):
        return jsonify(error="Enter a valid UPI ID, such as name@bank."),400
    ref=secrets.token_hex(5).upper()
    add_ledger(current_user().id,pack,"purchase",f"{method.title()} simulated purchase",ref)
    db.session.commit()
    return jsonify(ok=True, coins=pack, balance=balance(current_user().id), receipt={"id":ref,"coins":pack,"paid_rupees":PACKS[pack],"method":method,"status":"Simulated success","created_at":datetime.utcnow().isoformat()})

@app.post("/api/gifts")
@roles("fan")
def send_gift():
    data=request.get_json(silent=True) or {}
    try:
        creator_id=int(data.get("creator_id",0)); amount=int(data.get("amount",0))
        message=safe_text(data.get("message",""),160)
    except (ValueError,TypeError) as e: return jsonify(error=str(e) or "Enter a valid amount."),400
    creator=db.session.get(User,creator_id)
    if not creator or creator.role!="creator": return jsonify(error="Choose a valid creator."),404
    if creator.id==current_user().id: return jsonify(error="You can't send a gift to yourself."),400
    if amount<1 or amount>10000: return jsonify(error="Enter an amount from 1 to 10,000 coins."),400
    now=time.time(); recent=[t for t in send_windows.get(current_user().id,[]) if now-t<10]
    if len(recent)>=5: return jsonify(error="You're sending too quickly. Wait a few seconds and try again."),429
    send_windows[current_user().id]=recent+[now]
    if balance(current_user().id)<amount: return jsonify(error="Not enough coins. Buy a coin pack to keep supporting creators."),400
    anonymous=bool(data.get("anonymous"))
    ref=secrets.token_hex(8)
    try:
        # One transaction: both ledger entries commit together.
        add_ledger(current_user().id,-amount,"gift_sent",f"Gift to {creator.username}",ref)
        add_ledger(creator.id,amount,"gift_received",f"Support from {'Anonymous fan' if anonymous else current_user().username}",ref)
        if message: notify(creator.id, f"{'An anonymous fan' if anonymous else current_user().username} sent {amount} coins: {message}", "gift")
        else: notify(creator.id, f"{'An anonymous fan' if anonymous else current_user().username} sent {amount} coins", "gift")
        db.session.commit()
    except Exception:
        db.session.rollback(); return jsonify(error="Gift didn't go through. Your balance was not changed."),500
    socketio.emit("gift_alert", {"amount":amount,"message":message,"sender":"Anonymous fan" if anonymous else current_user().username,"gift":data.get("gift","Supercoins")}, room=f"user_{creator.id}")
    return jsonify(ok=True,balance=balance(current_user().id),creator_balance=balance(creator.id),ref=ref)

@app.get("/api/ledger")
@login_required
def ledger():
    rows=Ledger.query.filter_by(user_id=current_user().id).order_by(Ledger.created_at.desc()).limit(100).all()
    return jsonify(transactions=[{"id":r.id,"amount":r.amount,"kind":r.kind,"note":r.note,"ref":r.ref,"created_at":r.created_at.isoformat()} for r in rows],balance=balance(current_user().id))

@app.get("/api/ledger/<int:row_id>/receipt")
@login_required
def receipt(row_id):
    r=Ledger.query.filter_by(id=row_id,user_id=current_user().id).first()
    if not r: return jsonify(error="Receipt not found."),404
    from io import BytesIO
    body=f"Streamer Buddy receipt\\nReceipt: SB-{r.id:06d}\\nDate: {r.created_at.isoformat()} UTC\\nType: {r.kind}\\nAmount: {r.amount:+d} coins\\nDetails: {r.note}\\nReference: {r.ref}\\n"
    return send_file(BytesIO(body.encode()), mimetype="text/plain", as_attachment=True, download_name=f"receipt-SB-{r.id:06d}.txt")

@app.post("/api/payouts")
@roles("creator")
def request_payout():
    data=request.get_json(silent=True) or {}
    try: coins=int(data.get("coins",0))
    except (ValueError,TypeError): return jsonify(error="Enter a valid coin amount."),400
    kind=data.get("kind","upi"); dest=str(data.get("destination","")).strip()
    rate,fee=settings()
    if coins<100: return jsonify(error="The minimum cash-out is 100 coins."),400
    if coins>balance(current_user().id): return jsonify(error="You don't have enough available coins."),400
    if kind not in ("upi","voucher"): return jsonify(error="Choose UPI or voucher."),400
    if kind=="upi" and not re.fullmatch(r"[A-Za-z0-9._-]{2,}@[A-Za-z]{2,}",dest): return jsonify(error="Enter a valid UPI ID."),400
    if kind=="voucher" and dest not in ("Amazon","Swiggy","Steam"): return jsonify(error="Choose a supported voucher."),400
    ref=secrets.token_hex(6).upper()
    # Escrow the coins immediately; rejected payouts refund them.
    add_ledger(current_user().id,-coins,"payout" if kind=="upi" else "voucher",f"{kind.title()} redemption request",ref)
    p=Payout(creator_id=current_user().id,coins=coins,amount_rupees=round(coins*rate*(1-fee/100),2),
             destination=dest,kind=kind,status="pending",redemption_code=secrets.token_urlsafe(8).upper() if kind=="voucher" else "")
    db.session.add(p); db.session.commit()
    return jsonify(ok=True,payout={"id":p.id,"coins":p.coins,"amount_rupees":p.amount_rupees,"destination":p.destination,"kind":p.kind,"status":p.status,"code":p.redemption_code})

@app.get("/api/payouts")
@roles("creator","admin")
def payouts():
    q=Payout.query.order_by(Payout.created_at.desc())
    if current_user().role!="admin": q=q.filter_by(creator_id=current_user().id)
    return jsonify(payouts=[{"id":p.id,"creator":db.session.get(User,p.creator_id).username,"coins":p.coins,"amount_rupees":p.amount_rupees,"destination":p.destination,"kind":p.kind,"status":p.status,"code":p.redemption_code,"created_at":p.created_at.isoformat()} for p in q.limit(100).all()])

@app.post("/api/admin/payout/<int:payout_id>")
@roles("admin")
def review_payout(payout_id):
    p=db.session.get(Payout,payout_id)
    if not p: return jsonify(error="Payout not found."),404
    data=request.get_json(silent=True) or {}; action=data.get("action")
    if p.status!="pending": return jsonify(error="This request has already been reviewed."),409
    if action not in ("approve","reject"): return jsonify(error="Choose approve or reject."),400
    p.status="paid" if action=="approve" else "rejected"
    if action=="reject": add_ledger(p.creator_id,p.coins,"refund",f"Refund for rejected payout #{p.id}",f"PAYOUT-{p.id}")
    notify(p.creator_id,f"Your payout request #{p.id} was {p.status}.","payout")
    db.session.commit()
    return jsonify(ok=True,status=p.status)

@app.get("/api/admin/stats")
@roles("admin")
def admin_stats():
    return jsonify(fans=User.query.filter_by(role="fan").count(),creators=User.query.filter_by(role="creator").count(),
       coins_sold=db.session.query(func.coalesce(func.sum(Ledger.amount),0)).filter_by(kind="purchase").scalar() or 0,
       coins_gifted=abs(db.session.query(func.coalesce(func.sum(Ledger.amount),0)).filter_by(kind="gift_sent").scalar() or 0),
       pending_payouts=Payout.query.filter_by(status="pending").count(),
       fees_earned=round(sum(p.coins*settings()[0]*settings()[1]/100 for p in Payout.query.filter_by(status="paid").all()),2),
       coin_rate=settings()[0],platform_fee=settings()[1])

@app.post("/api/admin/settings")
@roles("admin")
def update_settings():
    data=request.get_json(silent=True) or {}
    try: rate=float(data.get("coin_rate")); fee=float(data.get("platform_fee"))
    except (ValueError,TypeError): return jsonify(error="Enter valid numeric settings."),400
    if not (0.01<=rate<=100 and 0<=fee<=50): return jsonify(error="Rate must be 0.01–100 and fee 0–50%."),400
    for key,value in (("coin_rate",rate),("platform_fee",fee)):
        row=db.session.get(Setting,key)
        if row: row.value=str(value)
        else: db.session.add(Setting(key=key,value=str(value)))
    db.session.commit(); return jsonify(ok=True,coin_rate=rate,platform_fee=fee)

@app.get("/api/notifications")
@login_required
def notifications():
    rows=Notification.query.filter_by(user_id=current_user().id).order_by(Notification.created_at.desc()).limit(50).all()
    return jsonify(unread=sum(not n.read for n in rows),notifications=[{"id":n.id,"text":n.text,"kind":n.kind,"read":n.read,"created_at":n.created_at.isoformat()} for n in rows])

@app.post("/api/notifications/read")
@login_required
def read_notifications():
    Notification.query.filter_by(user_id=current_user().id,read=False).update({"read":True})
    db.session.commit(); return jsonify(ok=True)

@app.get("/api/wall")
def wall():
    creator_id=request.args.get("creator_id",type=int)
    if not creator_id: return jsonify(error="creator_id is required."),400
    start=datetime.utcnow()-timedelta(days=datetime.utcnow().weekday())
    sent=Ledger.query.filter(Ledger.kind=="gift_sent",Ledger.created_at>=start).all()
    totals={}
    for row in sent:
        # ref matches creator-side gift row; identify creator by matching ledger ref.
        received=Ledger.query.filter_by(ref=row.ref,kind="gift_received").first()
        if not received or received.user_id!=creator_id: continue
        totals[row.user_id]=totals.get(row.user_id,0)+abs(row.amount)
    result=[]
    for uid,coins in sorted(totals.items(),key=lambda x:x[1],reverse=True)[:5]:
        fan=db.session.get(User,uid)
        result.append({"username":fan.username,"coins":coins})
    return jsonify(week_start=start.date().isoformat(),leaders=result)

@app.post("/api/upload")
@roles("creator")
def upload():
    f=request.files.get("file")
    if not f: return jsonify(error="Choose an image to upload."),400
    if not f.mimetype.startswith("image/"): return jsonify(error="Only image files are supported."),400
    if f.mimetype not in ("image/jpeg","image/png","image/webp","image/gif"): return jsonify(error="Use a JPG, PNG, WEBP or GIF image."),400
    os.makedirs(app.config["UPLOAD_FOLDER"],exist_ok=True)
    name=secrets.token_hex(12)+"-"+secure_filename(f.filename)[:80]
    f.save(os.path.join(app.config["UPLOAD_FOLDER"],name))
    return jsonify(path="/uploads/"+name),201

@app.get("/uploads/<path:name>")
def uploaded_file(name):
    # only serve files inside the upload directory
    return send_file(os.path.join(app.config["UPLOAD_FOLDER"],secure_filename(name)))

@socketio.on("connect")
def socket_connect():
    u=current_user()
    if u: join_room(f"user_{u.id}")

def seed():
    db.create_all()
    if not Setting.query.first():
        db.session.add_all([Setting(key="coin_rate",value=str(COIN_RATE)),Setting(key="platform_fee",value=str(PLATFORM_FEE))])
    def user(username,email,password,role,bio="",category="gaming",live=False):
        u=User.query.filter_by(email=email).first()
        if not u:
            u=User(username=username,email=email,role=role,bio=bio,category=category,live=live)
            u.set_password(password); db.session.add(u); db.session.flush()
        return u
    admin=user("Admin","admin@sb.com","admin123","admin")
    nova=user("Nova Plays","nova@sb.com","demo123","creator","High-energy gaming, cozy chats & community nights.","gaming",True)
    pete=user("Pixel Pete","pete@sb.com","demo123","creator","Retro games, pixel art, and a little chaos.","art",False)
    sam=user("Sam","sam@sb.com","demo123","fan")
    riya=user("Riya","riya@sb.com","demo123","fan")
    for fan in (sam,riya):
        if not Ledger.query.filter_by(user_id=fan.id,kind="bonus").first(): add_ledger(fan.id,500,"bonus","Demo starter coins")
    if not Post.query.filter_by(creator_id=nova.id).first():
        db.session.add_all([
            Post(creator_id=nova.id,text="Tonight's challenge: can we beat the boss without taking a hit? 🎮",image="https://images.unsplash.com/photo-1542751371-adc38448a05e?w=900",pinned=True),
            Post(creator_id=nova.id,text="Thank you for making this community feel like home 💜",image="https://images.unsplash.com/photo-1511512578047-dfb367046420?w=900"),
            Post(creator_id=pete.id,text="Pixel art study of the week. What should I make next?",image="https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=900"),
        ])
    if not Follow.query.filter_by(fan_id=sam.id,creator_id=nova.id).first(): db.session.add(Follow(fan_id=sam.id,creator_id=nova.id))
    if not Ledger.query.filter_by(user_id=sam.id,kind="gift_sent").first():
        ref=secrets.token_hex(6); add_ledger(sam.id,-50,"gift_sent","Coffee for Nova",ref); add_ledger(nova.id,50,"gift_received","Support from Sam",ref)
    db.session.commit()

with app.app_context(): seed()

if __name__ == "__main__":
    socketio.run(app, debug=os.environ.get("FLASK_DEBUG")=="1", host="127.0.0.1", port=int(os.environ.get("PORT",5000)))
