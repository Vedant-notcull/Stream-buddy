# Streamer Buddy

A responsive Flask + SQLite prototype for a creator-support community. Includes role-based sessions, a coin ledger, simulated purchases, atomic gift transfers, creator posts, follows, comments, notifications, payout requests/review, admin rate settings, image upload, and Socket.IO creator alerts.

## Run locally

Requires Python 3.10+.

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000

## Demo logins

Use the buttons on the login page, or credentials below:

- Admin: `admin@sb.com` / `admin123`
- Creator Nova Plays: `nova@sb.com` / `demo123`
- Creator Pixel Pete: `pete@sb.com` / `demo123`
- Fan Sam: `sam@sb.com` / `demo123`
- Fan Riya: `riya@sb.com` / `demo123`

Demo login buttons select seeded accounts instantly. New accounts receive 100 welcome coins. Demo fans start with additional coins.

## Safety and payment notes

- Purchases are **simulated**. No payment provider is contacted and no card details are accepted or stored. The API is intentionally structured so a payment service adapter can replace `/api/wallet/buy`.
- Set a strong random `SECRET_KEY` environment variable before any deployment.
- Do not deploy the development server. Use a production WSGI server and configure Socket.IO appropriately.
- Before production: add CSRF protection, HTTPS, stricter CSP, database migrations, audit logging, persistent distributed rate limiting, verified image decoding/re-encoding and size limits, moderation provider integration, proper payout/KYC/tax workflows, real payment webhooks with idempotency, and comprehensive automated tests.
- SQLite is suitable for local/demo use; use PostgreSQL and row-level locking for production money/coin workflows.
- Coin rate defaults to ₹0.10 per coin and platform fee to 10%. Admin can change both in the panel.
- This is a demo, not a production-ready financial platform. Voucher/payout processing is simulated.

## Project layout

- `app.py`: models, JSON REST routes, demo seeding and Socket.IO
- `templates/index.html`: app shell
- `static/app.css`: responsive design system and components
- `static/app.js`: client-side routing, API calls and interactions
- `uploads/`: uploaded creator images
